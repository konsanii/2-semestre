package DAO;

/**
 *
 * @author Alunos
 */
public class Usuarios {
    private String Login;
    private String Senha;
    private int ID_Cli;
    private String Num_CC;
    
public Usuarios(String Login, String Senha, int ID_Cli, String Num_CC){
    this.ID_Cli = ID_Cli;
    this.Senha = Senha;
    this.Login = Login;


this.Num_CC = Num_CC;
}

public Usuarios(){
}
     public String dadosSQLValue(){
        String dadosClientes;
        dadosClientes = "'"
            + this.getLogin() + "','"
            + this.getSenha() + "','"
            + this.getID_Cli() + "','"
            + this.getNum_CC() + "'";
        
        return dadosClientes;
    }
    public String getLogin() {
        return Login;
    }

    public void setLogin(String Login) {
        this.Login = Login;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public int getID_Cli() {
        return ID_Cli;
    }

    public void setID_Cli(int ID_Cli) {
        this.ID_Cli = ID_Cli;
    }

    public String getNum_CC() {
        return Num_CC;
    }

    public void setNum_CC(String Num_CC) {
        this.Num_CC = Num_CC;
    }
   
    
    
}
  
